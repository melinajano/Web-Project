from django import forms
from django.contrib.auth.models import User
from partner.models import Partner

class PartnerForm(forms.Form):
    username = forms.CharField()
    name = forms.CharField()
    surname = forms.CharField()
    password = forms.CharField(widget=forms.PasswordInput())
    email = forms.EmailField()


    def save(self):
        username = self.cleaned_data['username']
        email = self.cleaned_data['email']
        password = self.cleaned_data['password']
        name = self.cleaned_data['name']
        surname = self.cleaned_data['surname']

        user = User.objects.create(username=username, 
                                   email=email,
                                   first_name=name,
                                   last_name=surname)
        user.set_password(password)
        user.save()

        partner = Partner.objects.create(
                                    user=user,
                                    name=name,
                                    surname=surname,
                                    email=email
        )
        

class PartnerFormUpdate(forms.ModelForm):
    
    class Meta:
        model = Partner
        fields = ['name', 'surname', 'email']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter name'}),
            'surname': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter surname'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter email'}),
        }