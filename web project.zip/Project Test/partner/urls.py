from django.urls import path
from partner import views

urlpatterns = [
    path('partner-info/',views.partnerInfo, name='partner-info'),
    path('partner-create/',views.createPartner, name='create-partner'),
    path('partner-update/<int:id>/',views.updatePartner, name='update-partner'),
    path('verify-partner',views.verifyPartner, name='verify-partner'),
]