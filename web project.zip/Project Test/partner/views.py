from django.shortcuts import render, redirect
from django.http import Http404, HttpResponseRedirect
from partner.forms import PartnerForm, PartnerFormUpdate
from partner.models import Partner


def partnerInfo(request):
    partner = Partner.objects.filter(isActive=True, isConfirmed=True, isDeleted=False)
    if request.method=='POST':
        partnerId=request.POST.get("partnerId")
        currentPartner=Partner.objects.filter(id=partnerId).first()
        currentPartner.isActive=False
        currentPartner.isConfirmed=False
        currentPartner.isDeleted=True
        currentPartner.save()

        return redirect('partner-info')
    
    context = {'partnerInfo': partner}
    return render(request, 'partners/showMessage.html', context)


def createPartner(request):
    
    if request.method == 'POST':
        partnerForm = PartnerForm(request.POST)
        if partnerForm.is_valid():
            partnerForm.save()
            return redirect('partner-info')

    else:
        partnerForm = PartnerForm()   

    return render(request, 'partners/createPartner.html', {'partnerForm': partnerForm})


def updatePartner(request, id):
    currentPartner = Partner.objects.get(id=id)
    
    if request.method == 'POST':
        partnerForm = PartnerFormUpdate(request.POST, instance=currentPartner)
        
        if partnerForm.is_valid():
            partnerForm.save()
            return redirect('partner-info')

    else:
        partnerForm = PartnerFormUpdate(instance=currentPartner)   

    return render(request, 'partners/createPartner.html', {'partnerForm': partnerForm})

def verifyPartner(request):
    partner = Partner.objects.filter(isActive=False, isConfirmed=False, isDeleted=False)
    if request.method=='POST':
        partnerId=request.POST.get("partnerId")
        currentPartner=Partner.objects.filter(id=partnerId).first()
        currentPartner.isActive=True
        currentPartner.isConfirmed=True
        currentPartner.save()

        return redirect('verify-partner')
    context = {'partnerInfo': partner}
    return render(request, 'partners/verifyPartners.html', context)






