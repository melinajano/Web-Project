from django.db import models
from django.contrib.auth.models import User

class Partner(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=50)
    surname = models.CharField(max_length=50)
    email = models.EmailField()
    isActive=models.BooleanField(default=False)
    isDeleted=models.BooleanField(default=False)
    isConfirmed=models.BooleanField(default=False)
    class Meta:
        db_table = 'partners'

    def __str__(self):
        return self.name + ' ' + self.surname
