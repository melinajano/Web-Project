from django.urls import path
from underwriter import views

urlpatterns = [
    path('underwriter-info/',views.underwriterInfo, name='underwriter-info'),
    path('underwriter-create/',views.createUnderwriter, name='create-underwriter'),
    path('underwriter-update/<int:id>/',views.updateUnderwriter, name='update-underwriter'),
]