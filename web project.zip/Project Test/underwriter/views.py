from django.shortcuts import render, redirect
from underwriter.forms import UnderwriterForm, UnderwriterFormUpdate
from underwriter.models import Underwriter


def underwriterInfo(request):
    underwriters = Underwriter.objects.all()

    return render(request, 'underwriters/underwriter.html', {'underwriters': underwriters})


def createUnderwriter(request):
    
    if request.method == 'POST':
        underwriterForm = UnderwriterForm(request.POST)
        if underwriterForm.is_valid():
            underwriterForm.save()
            return redirect('underwriter-info')

    else:
        underwriterForm = UnderwriterForm()   

    return render(request, 'underwriters/createUnderwriter.html', {'underwriterForm': underwriterForm} )

def updateUnderwriter(request, id):
    currentUnderwriter = Underwriter.objects.get(id=id)
    
    if request.method == 'POST':
        underwriterForm = UnderwriterFormUpdate(request.POST, instance=currentUnderwriter)
        
        if underwriterForm.is_valid():
            underwriterForm.save()
            return redirect('underwriter-info')

    else:
        underwriterForm = UnderwriterFormUpdate(instance=currentUnderwriter)   

    return render(request, 'underwriters/createUnderwriter.html', {'underwriterForm': underwriterForm})