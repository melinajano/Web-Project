from django.db import models

from django.db import models
from django.contrib.auth.models import User

class Underwriter(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=50)
    surname = models.CharField(max_length=50)
    email = models.EmailField()

    class Meta:
        db_table = 'underwriters'
        
    def __str__(self):
        return self.name + ' ' + self.surname
