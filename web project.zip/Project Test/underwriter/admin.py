from django.contrib import admin
from .models import Underwriter

@admin.register(Underwriter)
class UnderwriterAdmin(admin.ModelAdmin):
    list_display = [
        'id',
        'user',
        'name',
        'surname',
        'email'
    ]
    