from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from partner.models import Partner
from underwriter.models import Underwriter
import random, string
from project.settings import EMAIL_HOST_USER
from django.core.mail import send_mail

# Create your views here.

def generateCode(length):
    letters = string.ascii_letters
    generatedCode = "".join(random.choice(letters) for i in range(length))
    return generatedCode


def home(request):
    print(request.user)
    return render(request, 'homepage.html')


def login_view(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            if Partner.objects.filter(user=user).exists():
                return redirect('partner-info') # redirect te lista e partnerve 
            elif Underwriter.objects.filter(user=user).exists():
                return redirect('underwriter-info') # redirect te lista e underwriter
            else:
                return HttpResponse("You are not authorized to access this page.")
        else:
            return HttpResponse("Username or Password incorrect")
        
    return render(request, 'login.html')

subject='Kerkese per rigjenerim passwordi'

def reset_password(request):
    if request.method=='POST':
        username=request.POST.get('username')
        email=request.POST.get('email')
        user=User.objects.filter(username=username).first()

        if user is not None:
            password = generateCode(8)
            user.set_password(password)
            user.save()

            message=f'Pershendetje {user.first_name} {user.last_name} \n\n Kodi juaj i ri eshte: {password}. \n\n Faleminderit!'
            send_mail (subject, message, from_email=EMAIL_HOST_USER,recipient_list=[user.email], fail_silently=False )

        
    return render(request, 'loginForget.html')