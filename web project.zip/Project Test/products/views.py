from django.shortcuts import redirect, render
import products
from products.forms import ProductForm, ProductFormUpdate, ProductPartnerFormUpdate
from products.models import Products
from products.models import PartnerProducts
from products.forms import ProductPartnerForm

# Create your views here.
def productList(request):
        productList = Products.objects.filter(isActive=True, isConfirmed=True, isDeleted=False)
        if request.method=='POST':
            productId=request.POST.get("productId")
            currentProduct=Products.objects.filter(id=productId).first()
            currentProduct.isActive=False
            currentProduct.isConfirmed=False
            currentProduct.isDeleted=True
            currentProduct.save()

            return redirect('product-list')
        context={'productList': productList}
        return render(request, 'products/productList.html', context)

def createProduct(request):

        if request.method == 'POST':
            productForm = ProductForm(request.POST)
            if productForm.is_valid():
                productForm.save()
                return redirect('product-list')
        
        else:
            productForm = ProductForm()   

        return render(request, 'products/createProduct.html', {'productForm': productForm})

def productPartner(request):
      if request.method== 'POST':
            partnerProduct= ProductPartnerForm(request.POST)
            if partnerProduct.is_valid():
                partnerProduct.save()
                return redirect('product-partner')
            
      else: 
            partnerProduct=ProductPartnerForm()
        
      return render(request, 'products/partnerProduct.html', {'partnerProduct': partnerProduct})


def productPartnerList(request):
      productPartnerList= PartnerProducts.objects.filter(isActive=True, isConfirmed=True, isDeleted=False)
      if request.method=='POST':
            productPartnerId=request.POST.get("productPartnerId")
            currentProductPartner=PartnerProducts.objects.filter(id=productPartnerId).first()
            currentProductPartner.isActive=False
            currentProductPartner.isConfirmed=False
            currentProductPartner.isDeleted=True
            currentProductPartner.save()

            return redirect('product-partnerList')
      context={'productPartnerList':productPartnerList}
      return render(request, 'products/productPartnerList.html', context)

def updateProduct(request, id):
    currentProduct = Products.objects.get(id=id)
    
    if request.method == 'POST':
        productForm = ProductFormUpdate(request.POST, instance=currentProduct)
        
        if productForm.is_valid():
            productForm.save()
            return redirect('product-list')

    else:
        productForm = ProductFormUpdate(instance=currentProduct)   

    return render(request, 'products/createProduct.html', {'productForm': productForm})

def updateProductPartner(request, id):
    currentProductPartner = PartnerProducts.objects.get(id=id)
    
    if request.method == 'POST':
        productPartnerForm = ProductPartnerFormUpdate(request.POST, instance=currentProductPartner)
        
        if productPartnerForm.is_valid():
            productPartnerForm.save()
            return redirect('product-partnerList')

    else:
        productPartnerForm = ProductFormUpdate(instance=currentProductPartner)   

    return render(request, 'products/partnerProduct.html', {'productPartnerForm': productPartnerForm})

def verifyProduct(request):
    productList = Products.objects.filter(isActive=False, isConfirmed=False, isDeleted=False)
    if request.method=='POST':
        productId=request.POST.get("productId")
        currentProduct=Products.objects.filter(id=productId).first()
        currentProduct.isActive=True
        currentProduct.isConfirmed=True
        currentProduct.save()

        return redirect('verify-product')
    context = {'productList': productList}
    return render(request, 'products/verifyProduct.html', context)

def verifyProductPartner(request):
    productPartnerList = PartnerProducts.objects.filter(isActive=False, isConfirmed=False, isDeleted=False)
    if request.method=='POST':
        productPartnerId=request.POST.get("productPartnerId")
        productPartner=PartnerProducts.objects.filter(id=productPartnerId).first()
        productPartner.isActive=True
        productPartner.isConfirmed=True
        productPartner.save()

        return redirect('verify-product-partner')
    context = {'productPartnerList': productPartnerList}
    return render(request, 'products/verifyProductPartner.html', context)

