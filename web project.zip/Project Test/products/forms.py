from django import forms
from django.contrib.auth.models import User
from products.models import Products
from django.forms import CharField, ModelChoiceField, TextInput, Select, NumberInput, FloatField, IntegerField
from partner.models import Partner
from .models import PartnerProducts

class ProductForm(forms.Form):
    product_name= forms.CharField(max_length=30)
    product_price= forms.DecimalField(max_digits=5, decimal_places=2)
    product_description= forms.CharField(max_length=150)

    
    def save(self):
        product_name = self.cleaned_data['product_name']
        product_price = self.cleaned_data['product_price']
        product_description = self.cleaned_data['product_description']

        product = Products.objects.create(
            product_name=product_name,
            product_price=product_price,
            product_description=product_description
            )
        product.save()

class ProductPartnerForm(forms.Form):
    partner= ModelChoiceField(queryset=Partner.objects.all(), label= 'Zgjidhni partnerin:', required=True,widget=Select())
    product= ModelChoiceField(queryset=Products.objects.all(), label= 'Zgjidhni produktin:', required=True,widget=Select())
    startDate=forms.DateField(widget=forms.TextInput(attrs={'type':'date'}), label='Start Date')
    endDate=forms.DateTimeField(widget=forms.TextInput(attrs={'type':'date'}), label='End Date')
    

    def save(self):
        partner= self.cleaned_data['partner']
        product = self.cleaned_data['product']
        startDate= self.cleaned_data['startDate']
        endDate= self.cleaned_data['endDate']

        partnerProduct= PartnerProducts.objects.create(
                                                        partner=partner,
                                                        product=product,
                                                        startDate=startDate,
                                                        endDate=endDate
                                                    )
        return partnerProduct

class ProductFormUpdate(forms.ModelForm):
    
    class Meta:
        model = Products
        fields = ['user', 'product_name', 'product_price', 'product_description']
        widgets = {
            'user': forms.Select(attrs={'class': 'form-control'}),
            'product_name': forms.TextInput(attrs={'class': 'form-control'}),
            'product_price': forms.NumberInput(attrs={'class': 'form-control'}),
            'product_description': forms.Textarea(attrs={'class': 'form-control'}),
        }

class ProductPartnerFormUpdate(forms.ModelForm):
    
    class Meta:
        model = PartnerProducts
        fields = ['partner', 'product', 'startDate', 'endDate', 'isActive', 'isConfirmed', 'isAssigned', 'isDeleted', 'isExpired']
        widgets = {
            'startDate': forms.DateInput(attrs={'type': 'date'}),
            'endDate': forms.DateInput(attrs={'type': 'date'}),
        }