from django.urls import path
from products import views

urlpatterns = [
    path('products/',views.productList, name='product-list'),
    path('product-create/',views.createProduct, name='product-create'),
    path('product-partner/', views.productPartner, name='product-partner'),
    path('product-partnerList/', views.productPartnerList, name='product-partnerList'),
    path('product-update/<int:id>/',views.updateProduct, name='update-product'),
    path('product-partner-update/<int:id>/',views.updateProductPartner, name='update-product-partner'),
    path('verify-product',views.verifyProduct, name='verify-product'),
    path('verify-product-partner',views.verifyProductPartner, name='verify-product-partner'),

]