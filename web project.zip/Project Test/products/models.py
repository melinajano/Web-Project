from django.db import models
from django.contrib.auth.models import User
from partner.models import Partner 

# Create your models here.
class Products(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    product_name= models.CharField(max_length=30)
    product_price= models.DecimalField(max_digits=5, decimal_places=2)
    product_description= models.CharField(max_length=150)
    isActive=models.BooleanField(default=False)
    isDeleted=models.BooleanField(default=False)
    isConfirmed=models.BooleanField(default=False)


    class Meta:
        db_table= 'products'

    def __str__(self):
        return self.product_name
        
class PartnerProducts(models.Model):
    partner = models.ForeignKey(Partner, on_delete=models.CASCADE, null=True, blank=True)
    product= models.ForeignKey(Products, on_delete=models.CASCADE, null=True, blank=True)
    startDate= models.DateField(null=True,  blank= True)
    endDate= models.DateField(null=True,  blank= True)
    isActive= models.BooleanField(default=False)
    isConfirmed= models.BooleanField(default=False)
    isAssigned= models.BooleanField(default=False)
    isDeleted= models.BooleanField(default=False)
    isExpired= models.BooleanField(default=False)

    class Meta:
        db_table= 'partner_products'

    def __str__(self):
        return self.partner.name + ' - ' + self.product.product_name
        