from django.contrib import admin
from .models import Products
from .models import PartnerProducts

@admin.register(Products)
class ProductAdmin(admin.ModelAdmin):
    list_display = [
        'product_name',
        'product_price',
        'product_description',
    ]

@admin.register(PartnerProducts)
class ProductAdmin(admin.ModelAdmin):
    list_display = [
        'partner',
        'product',
        'startDate',
        'endDate',
        'isActive',
        'isConfirmed',
        'isAssigned',
        'isDeleted',
        'isExpired'
    ]
    
