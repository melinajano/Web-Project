from django import forms
from .models import Question

class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['name', 'email', 'question_text']

    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    question_text = forms.CharField(widget=forms.Textarea)