from django.urls import path
from .views import AskQuestionView

urlpatterns = [
    path('question/', AskQuestionView.as_view(), name='ask-question'),
]