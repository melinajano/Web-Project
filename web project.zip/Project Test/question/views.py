from django.shortcuts import render
from django.views.generic.edit import FormView
from .forms import QuestionForm

class AskQuestionView(FormView):
    template_name = 'ask_question.html'
    form_class = QuestionForm
    success_url = '/question/'

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)